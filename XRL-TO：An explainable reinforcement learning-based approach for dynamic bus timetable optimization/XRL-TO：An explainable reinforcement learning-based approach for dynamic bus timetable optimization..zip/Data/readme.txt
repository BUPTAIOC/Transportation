file name:“line id-direction-X.csv”

X=0   : 2018-06-08
X=1   : 2018-06-15
X=2   : 2018-06-22
X=3   : 2018-06-29
X=4   : 2018-07-06

LABEL：unique identifier of the passenger
ARRIVAL_MARKTIMES：passenger's arrival time
MARKTIME_TIME：passenger's card swipe time
MARKSTATION：passenger's boarding station
PREDICTSTATION：passenger's alighting station
